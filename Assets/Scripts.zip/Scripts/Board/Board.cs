using Cells;
using Pieces;
using System.Collections.Generic;
using UnityEngine;

namespace Boards
{
    public class Board : MonoBehaviour
    {
        [SerializeField] private Cell cellNormal;
        [SerializeField] private Cell cellTrap;
        [SerializeField] private Cell cellCave;
        [SerializeField] private Cell cellRiver;

        [SerializeField] private Piece piece;

        private static readonly int[] CaveIds = { 27, 35 };
        private static readonly int[] RiverIds = { 12, 13, 14, 21, 22, 23, 39, 40, 41, 48, 49, 50 };
        private static readonly int[] TrapIds = { 18, 28, 36, 26, 34, 44 };

        private List<Cell> cellList = new List<Cell>();

        private const int BoardWidth = 7;
        private const int BoardLength = 9;

        public static Board Instance;

        private void Init()
        {
            var id = 0;
            for (var i = 0; i < BoardWidth; i++)
            {
                for (var j = 0; j < BoardLength; j++)
                {
                    var cellPrefab = GetCellPrefab(id);
                    var cell = Instantiate(cellPrefab, this.transform);
                    cell.transform.position = new Vector3(i, 0f, j);
                    cell.Init(id, i, j);
                    cellList.Add(cell);
                    id++;
                }
            }
        }

        private void AddEvent()
        {
            Piece.OnClickHandler += OnClickPiece;
        }

        private void RemoveEvent()
        {
            Piece.OnClickHandler -= OnClickPiece;
        }

        private void Awake()
        {
            if (Instance != null && Instance != this)
            {
                Destroy(this.gameObject);
            }
            else
            {
                Instance = this;
            }

            Init();
            AddEvent();
        }

        private void OnDestroy()
        {
            RemoveEvent();
        }

        private void OnClickPiece(int pieceCellId)
        {
            if (pieceCellId < 0 || pieceCellId >= cellList.Count)
            {
                Debug.LogError($"Piece's cell ID is invalid.");
                return;
            }

            var pieceSouth = GetCell(pieceCellId - 1);
            var pieceWest = GetCell(pieceCellId - 9);
            var pieceNorth = GetCell(pieceCellId + 1);
            var pieceEast = GetCell(pieceCellId + 9);


        }

        private Cell GetCellPrefab(int id)
        {
            // Check if cell is Cave
            if (CaveIds.Contains(id))
            {
                return cellCave;
            }

            // Check if cell is River
            if (RiverIds.Contains(id))
            {
                return cellRiver;
            }

            // Check if cell is Trap
            if (TrapIds.Contains(id))
            {
                return cellTrap;
            }

            // return Normal
            return cellNormal;
        }

        public Cell GetCell(int id)
        {
            foreach(var item in cellList)
            {
                if (item.Id == id)
                {
                    return item;
                }
            }

            return null;
        }
    }
}