﻿using System.Collections.Generic;
using Boards;
using Players;
using UnityEngine;

namespace Pieces
{
    public class PieceManager : MonoBehaviour
    {
        [Header("Piece Prefabs")]
        [SerializeField] private Piece elephantPrefab;
        [SerializeField] private Piece lionPrefab;
        [SerializeField] private Piece tigerPrefab;
        [SerializeField] private Piece leopardPrefab;
        [SerializeField] private Piece dogPrefab;
        [SerializeField] private Piece wolfPrefab;
        [SerializeField] private Piece catPrefab;
        [SerializeField] private Piece ratPrefab;

        #region Variables

        // North player
        private static readonly List<(Rank rank, int cell)> NorthStartPositions = new()
        {
            (Rank.Elephant, 60),
            (Rank.Lion, 8),
            (Rank.Tiger, 62),
            (Rank.Leopard, 24),
            (Rank.Dog, 16),
            (Rank.Wolf, 42),
            (Rank.Cat, 52),
            (Rank.Rat, 6),
        };
        public List<Piece> _northPieces;

        // South player
        private static readonly List<(Rank rank, int cell)> SouthStartPositions = new()
        {
            (Rank.Elephant, 2),
            (Rank.Lion, 54),
            (Rank.Tiger, 0),
            (Rank.Leopard, 38),
            (Rank.Dog, 46),
            (Rank.Wolf, 20),
            (Rank.Cat, 10),
            (Rank.Rat, 56),
        };
        public List<Piece> _southPieces;

        #endregion

        #region Spawn Pieces

        private void SpawnPieces()
        {
            SpawnPieceForPlayer(PlayerPosition.North);
            SpawnPieceForPlayer(PlayerPosition.South);
        }

        private void SpawnPieceForPlayer(PlayerPosition playerPosition)
        {
            List<(Rank rank, int cell)> startPositions;
            PieceDirection direction;
            List<Piece> pieces;

            switch (playerPosition)
            {
                case PlayerPosition.North:
                    {
                        startPositions = NorthStartPositions;
                        direction = PieceDirection.North;
                        pieces = _northPieces;
                    }
                    break;

                case PlayerPosition.South:
                    {
                        startPositions = SouthStartPositions;
                        direction = PieceDirection.South;
                        pieces = _southPieces;
                    }
                    break;

                default:
                    return;
            }

            if (startPositions == null)
            {
                return;
            }

            foreach (var (rank, cellId) in startPositions)
            {
                SpawnPieceToCell(rank, cellId, direction, pieces);
            }
        }

        private void SpawnPieceToCell(Rank rank, int cellId, PieceDirection direction,
            List<Piece> pieces)
        {
            Piece piece = rank switch
            {
                Rank.Rat => SpawnPieceToCell(ratPrefab, cellId, direction),
                Rank.Cat => SpawnPieceToCell(catPrefab, cellId, direction),
                Rank.Dog => SpawnPieceToCell(dogPrefab, cellId, direction),
                Rank.Wolf => SpawnPieceToCell(wolfPrefab, cellId, direction),
                Rank.Leopard => SpawnPieceToCell(leopardPrefab, cellId, direction),
                Rank.Tiger => SpawnPieceToCell(tigerPrefab, cellId, direction),
                Rank.Lion => SpawnPieceToCell(lionPrefab, cellId, direction),
                Rank.Elephant => SpawnPieceToCell(elephantPrefab, cellId, direction),
                _ => null,

            };

            if (piece != null && pieces != null)
            {
                pieces.Add(piece);
            }
        }

        private Piece SpawnPieceToCell(Piece piece, int cellId, PieceDirection direction)
        {
            var cell = Board.Instance.GetCell(cellId);
            if (cell == null)
            {
                return null;
            }

            var position = cell.Position + new Vector3(0f, 0.6f, 0f);
            var p = Instantiate(piece, position, Quaternion.identity);
            p.transform.SetParent(transform);
            p.Init(cellId, direction);

            return p;
        }

        #endregion

        private void Init()
        {
            _southPieces = new();
            _northPieces = new();
        }

        public void MoveForward(Piece piece)
        {
            var currentCell = piece.CurrentCell;
            int destinationId = piece.Direction switch
            {
                PieceDirection.North => currentCell - 1,
                PieceDirection.South => currentCell + 1,
                _ => currentCell
            };

            var destination = Board.Instance.GetCell(destinationId);
            Debug.Log($"piece={piece.CurrentRank}, cur={currentCell}, des={destination.Id}");
            piece.MoveToCell(destination);
        }

        private void Awake()
        {
            Init();
        }

        private void Start()
        {
            SpawnPieces();
        }

        private void Update()
        {
            if (Input.GetKeyDown(KeyCode.Space))
            {
                MoveForward(_southPieces[0]);
                MoveForward(_northPieces[0]);
            }
        }
    }
}