﻿public enum PieceDirection
{
    North = 0,
    South = 1
}