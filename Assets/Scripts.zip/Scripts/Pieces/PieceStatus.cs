﻿namespace Pieces
{
    public enum PieceStatus
    {
        Alive = 0,
        Dead = 1,
    }
}