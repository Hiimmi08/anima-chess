﻿namespace Players
{
    public enum PlayerPosition
    {
        North = 0,
        South = 1,
    }
}