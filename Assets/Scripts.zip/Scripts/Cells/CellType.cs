namespace Cells
{
    public enum CellType 
    {
        Normal =0,
        River =1,
        Trap = 2,
        Cave = 3,
    }
}
