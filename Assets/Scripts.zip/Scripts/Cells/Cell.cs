using TMPro;
using UnityEngine;

namespace Cells
{
    public class Cell : MonoBehaviour
    {
        [SerializeField] private CellType cellType;
        public CellType Type => cellType;

        [SerializeField] private TMP_Text idLabel;

        public int Id { get; private set; }
        public Vector3 Position { get; private set; }

        public void Init(int id, int x, int z)
        {
            this.Id = id;
            idLabel.text = $"{id}";
            this.Position = new Vector3(x, 0f, z);
        }

        public void Highlight()
        {

        }
    }
}
